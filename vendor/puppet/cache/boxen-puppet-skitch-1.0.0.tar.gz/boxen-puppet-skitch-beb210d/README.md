# Skitch Puppet Module for Boxen

Install [Skitch](https://evernote.com/skitch/), a pretty good thing 
for making screenshots.

## Usage

```puppet
include skitch
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
